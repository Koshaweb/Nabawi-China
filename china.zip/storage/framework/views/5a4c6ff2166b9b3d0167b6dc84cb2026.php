
<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

 <?php $__env->slot('header', null, []); ?> 
    <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li class="px-3 py-2 border-b-4 border-white bg-gray-100 flex flex-col gap-2" style="width: 300px;"><p class="text-lg font-bold"><?php echo e($ser->{'name_'.app()->getLocale()}); ?></p>

        <p><?php echo e($ser->{'detail_'.app()->getLocale()}); ?></p>
    </li>




        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
 <?php $__env->endSlot(); ?>


<?php if(session()->has('success')): ?>
<div class="fixed lg:top-5 top-0  lg:left-96 lg:right-96 z-40 bg-yellow-700 p-6 text-center" x-data="{success: true}"  x-init="setTimeout(() => success = false, 10000 )" x-show="success">
    <h1 class="w-full h-full bg-white p-5 capitalize text-xl tracking-widest font-semibold"><?php echo app('translator')->get('lang.OrderMessage'); ?></h1>
</div>
<?php endif; ?>



<?php if(session()->has('contact')): ?>
<div class="fixed lg:top-5 top-0  lg:left-96 lg:right-96 z-40 bg-yellow-700 p-6 text-center" x-data="{contact: true}"  x-init="setTimeout(() => contact = false, 10000 )" x-show="contact">
    <h1 class="w-full h-full bg-white p-5 capitalize text-xl tracking-widest font-semibold"><?php echo app('translator')->get('lang.ContactMessage'); ?></h1>
</div>
<?php endif; ?>




<?php if(session()->has('member')): ?>
<div class="fixed lg:top-5 top-0  lg:left-96 lg:right-96 z-40 bg-yellow-700 p-6 text-center" x-data="{member: true}"  x-init="setTimeout(() => member = false, 10000 )" x-show="member">
    <h1 class="w-full h-full bg-white p-5 capitalize text-xl tracking-widest font-semibold"><?php echo app('translator')->get('lang.MemberMessage'); ?></h1>
</div>
<?php endif; ?>


<div>

    <?php $__currentLoopData = $bgimg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


    <div style="background-image: url(<?php echo e(asset($bg->homebg)); ?>);" class=" w-full bg-cover bg-center relative py-72">
        <div class="absolute top-0 left-0 bg-black z-10 w-full h-full opacity-20"> </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        


            <div class="lg:grid grid-cols-1 lg:grid-cols-3 w-full justify-center items-start z-20 absolute top-0 left-0 h-full px-12 py-12">
                <div class="flex flex-col gap-3 justify-center items-start h-full col-span-2">
                    <h1 class="text-3xl lg:text-6xl font-black text-white tracking-tighter"><strong><?php echo app('translator')->get('lang.CompanyName'); ?></strong> </h1>
                    <h1 class=" text-xl lg:text-white text-3xl font-thin tracking-widest"><?php echo app('translator')->get('lang.Claim'); ?></h1>
                    <button class="px-9 py-3 bg-yellow-700 text-white text-lg font-black mt-8" id="orderbtn"><?php echo app('translator')->get('lang.order'); ?></button>
                 </div>









         <div class="bg-black fixed top-0 left-0 h-full w-full z-40 p-20 opacity-50 hidden transition duration-500" id="orderlayer"></div>

         <div class="bg-white p-10 overflow-y-scroll z-50 fixed margins flex flex-col gap-6 hidden transition duration-500" id="ordermodel">
             <div class="flex justify-between">
                <h1 class="text-center text-lg lg:text-3xl font-bold w-1/2 lg:w-full"><?php echo app('translator')->get('lang.FormTitle'); ?></h1>
                 <button class="px-2 text-sm lg:lg lg:px-5 lg:py-1 bg-yellow-700 text-white h-fit py-1" id="closeorder"><?php echo app('translator')->get('lang.Close'); ?></button>
             </div>
             <div class="py-4">



                    <form action="/storeorder" method="POST" class="flex flex-col gap-6 py-3 px-1 lg:px-4">
                        <?php echo csrf_field(); ?>

                        <div class="flex flex-col gap-1 opacity-70">
                            <span><?php echo app('translator')->get('lang.FullName'); ?>*</span>
                            <input type="text" name="name" placeholder="eg. Shokrullah Kosha" class="w-full border rounded-lg p-3" required>
                        </div>


                        <div class="flex flex-col gap-1 opacity-70">
                            <span><?php echo app('translator')->get('lang.Email'); ?></span>
                            <input type="email" name="email" placeholder="eg. sh.kosha2020@gmail.com" class="w-full border rounded-lg p-3" required>
                        </div>



                        <div class="flex flex-col gap-1 opacity-70">
                            <span><?php echo app('translator')->get('lang.WhatsApp'); ?></span>
                            <input type="number" name="number" placeholder="eg. +923201162723" class="w-full border rounded-lg p-3" required>
                        </div>



                        <div  class="flex flex-col gap-1 opacity-70">
                            <span><?php echo app('translator')->get('lang.ProductDetails'); ?></span>
                            <textarea name="detail" cols="4" rows="4"  class="w-full border rounded-lg p-3" required></textarea>
                        </div>




                        <div class="flex flex-col gap-1 opacity-70">
                            <span><?php echo app('translator')->get('lang.DeliveryType'); ?></span>
                            <div class="flex gap-3 items-center">
                                <input type="radio" id="plane" name="delivery" value="By Airplane">
                                <label for="plane"><?php echo app('translator')->get('lang.Airplane'); ?></label>
                            </div>

                            <div class="flex gap-3 items-center">
                                <input type="radio" id="ship" name="delivery" value="By Ship">
                                <label for="ship"><?php echo app('translator')->get('lang.Ship'); ?></label>
                            </div>
                        </div>




                        <div class="flex flex-col gap-1 opacity-70">
                            <span><?php echo app('translator')->get('lang.PostOfficeAddress'); ?></span>
                            <input type="text" name="address" placeholder="eg. TCS Office, Ali Abad, Quetta, PK" class="w-full border rounded-lg p-3" required>
                        </div>


                        <button class="bg-yellow-700 px-5 py-1 text-white w-fit mx-auto"><?php echo app('translator')->get('lang.submit'); ?></button>

                    </form>


            </div>

         </div>







                <div class="col-span-1 hidden lg:flex justify-center items-center h-full border-2 border-white w-full flex-col gap-4 shadow-xl shadow-white bg-gray-900 opacity-70">
                    <h1 class="text-xl font-bold text-white"><?php echo app('translator')->get('lang.contactus'); ?></h1>

                    <?php if(App::getLocale() == 'en'): ?>



                    <form action="storecontact" method="POST" class="flex flex-col gap-3 w-full p-4">
                        <?php echo csrf_field(); ?>
                        <div class="flex flex-col gap-1 text-white">
                            <span><?php echo app('translator')->get('lang.FullName'); ?></span>
                            <input type="text" name="name" class="p-2 w-full bg-transparent border-b rounded-lg border-white" required>
                        </div>


                        <div class="flex gap-2 w-full">
                            <div class="flex flex-col gap-1 text-white w-full">
                                <span><?php echo app('translator')->get('lang.Email'); ?></span>
                                <input type="email" name="email" class="p-2 w-full bg-transparent border rounded-lg border-white" required>
                            </div>

                            <div class="flex flex-col gap-1 text-white w-full">
                                <span><?php echo app('translator')->get('lang.WhatsApp'); ?></span>
                                <input type="number" name="number" class="p-2 w-full bg-transparent border rounded-lg border-white" required>
                            </div>
                        </div>



                        <div class="flex flex-col gap-1 text-white">
                            <span><?php echo app('translator')->get('lang.Message'); ?></span>
                            <textarea name="message" cols="3" rows="3" class="p-2 w-full bg-transparent border rounded-lg border-white" required></textarea>
                        </div>

                        <button class="bg-yellow-700 px-4 py-1 text-white w-fit mx-auto rounded hover:bg-transparent hover:border border-yellow-700 transition duration-500"><?php echo app('translator')->get('lang.submit'); ?></button>
                    </form>

                    <?php else: ?>

                    <form action="storecontact" method="POST" class="flex flex-col gap-3 w-full p-4 text-right">
                        <?php echo csrf_field(); ?>
                        <div class="flex flex-col gap-1 text-white">
                            <span><?php echo app('translator')->get('lang.FullName'); ?></span>
                            <input type="text" name="name" class="p-2 w-full bg-transparent border-b rounded-lg border-white" required>
                        </div>


                        <div class="flex gap-2 w-full">
                            <div class="flex flex-col gap-1 text-white w-full">
                                <span><?php echo app('translator')->get('lang.Email'); ?></span>
                                <input type="email" name="email" class="p-2 w-full bg-transparent border rounded-lg border-white" required>
                            </div>

                            <div class="flex flex-col gap-1 text-white w-full">
                                <span><?php echo app('translator')->get('lang.WhatsApp'); ?></span>
                                <input type="number" name="number" class="p-2 w-full bg-transparent border rounded-lg border-white" required>
                            </div>
                        </div>



                        <div class="flex flex-col gap-1 text-white">
                            <span><?php echo app('translator')->get('lang.Message'); ?></span>
                            <textarea name="message" cols="3" rows="3" class="p-2 w-full bg-transparent border rounded-lg border-white" required></textarea>
                        </div>

                        <button class="bg-yellow-700 px-4 py-1 text-white w-fit mx-auto rounded hover:bg-transparent hover:border border-yellow-700 transition duration-500"><?php echo app('translator')->get('lang.submit'); ?></button>
                    </form>

                    <?php endif; ?>

                </div>


            </div>



    </div>




    

    <div class="lg:py-12 py-8 px-4">

        <?php if(App::getLocale() == 'en'): ?>

        <div class=" px-4 text-3xl font-bold">
            <h1 class="border-b border-black py-4"><?php echo app('translator')->get('lang.Our'); ?> <span class="text-yellow-700"><?php echo app('translator')->get('lang.Category'); ?></span></h1>
        </div>

        <?php else: ?>
        <div class=" px-4 text-3xl font-bold flex justify-end border-b border-black">
            <h1 class=" py-4"><?php echo app('translator')->get('lang.Category'); ?> <span class="text-yellow-700"><?php echo app('translator')->get('lang.Our'); ?></span></h1>
        </div>

        <?php endif; ?>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 py-8">

            <?php $__currentLoopData = $allct; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $allcts): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <a href="allct/<?php echo e($allcts->id); ?>/show" style="background-image: url(<?php echo e(asset($allcts->img)); ?>);" class="bg-cover bg-center p-4 w-full h-72 relative">
                <div class="absolute top-0 left-0 bg-black z-10 w-full h-full opacity-30"> </div>
                <div class="absolute top-0 left-0 z-20 h-full w-full flex justify-center items-center text-2xl font-bold text-white">
                    <h1><?php echo e($allcts->{'name_'.app()->getLocale()}); ?></h1>
                </div>
            </a>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>
    </div>








    <div style="background-image: url(<?php echo e(asset('imgs/subs.jpg')); ?>)" class="bg-cover bg-center w-full h-60 lg:h-44 relative">
        <div class="bg-black absolute top-0 left-0 h-full w-full z-10 opacity-40"></div>
        <div class="absolute top-0 left-0 h-full w-full grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 z-20 items-center px-10 py-16">
            <div class="flex flex-col gap-1 text-white ">
                <h1 class="text-xl lg:text-3xl font-bold"><?php echo app('translator')->get('lang.SignUp'); ?></h1>
                <p class="opacity-90 tracking-tighter text-lg lg:text-xl text-yellow-700"><?php echo app('translator')->get('lang.MemberDiscount'); ?></p>
            </div>

            <form action="storeemail" method="POST" class="relative w-full mt-4 lg:mt-0">
                <?php echo csrf_field(); ?>
                <input type="email" name="email" placeholder="Enter Your Email Address" class="px-5 py-3  w-full" required>
                <button class="bg-yellow-700 px-6 py-1 text-white absolute right-0 top-0 h-full "><?php echo app('translator')->get('lang.submit'); ?></button>
            </form>
        </div>
    </div>








    

    <div class="px-4">

        <?php if(App::getLocale() == 'en'): ?>
        <div class=" px-4 text-3xl font-bold">
            <h1 class="border-b border-black py-4"><?php echo app('translator')->get('lang.Our'); ?><span class="text-yellow-700"> <?php echo app('translator')->get('lang.Feature'); ?></span></h1>
        </div>

        <?php else: ?>

        <div class=" px-4 text-3xl font-bold flex justify-end border-b border-black">
            <h1 class=" py-4"> <?php echo app('translator')->get('lang.Feature'); ?><span class="text-yellow-700"><?php echo app('translator')->get('lang.Our'); ?></span></h1>
        </div>

        <?php endif; ?>

        <div class="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 py-12 gap-6 px-8">

            <?php $__currentLoopData = $featured; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fe): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="w-full h-fit">
                <div style="background-image: url(<?php echo e(asset($fe->img)); ?>);" class="bg-cover bg-center w-full h-32"></div>
                <div class="flex flex-col gap-3 py-2">
                    <span class="font-thin"><?php echo e($fe->{'name_'.app()->getLocale()}); ?></span>
                    <span class="text-lg font-semibold tracking-wider"><?php echo e($fe->price); ?></span>
                    <a href="<?php echo e($fe->id); ?>/order" class="px-3 py-1 bg-yellow-700 text-white text-sm font-thin w-fit"><?php echo app('translator')->get('lang.order'); ?></a>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


        </div>

    </div>

</div>


<script src="<?php echo e(asset('dist/public.js')); ?>"></script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laravel\projects\china\resources\views/frontpages/index.blade.php ENDPATH**/ ?>