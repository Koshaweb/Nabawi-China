<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>


     <?php $__env->slot('header', null, []); ?> 
        <?php $__currentLoopData = $service; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ser): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <li class="px-3 py-2 border-b-4 border-white bg-gray-100 flex flex-col gap-2" style="width: 600px;"><p class="text-lg font-bold"><?php echo e($ser->{'name_'.app()->getLocale()}); ?></p>

            <p><?php echo e($ser->{'detail_'.app()->getLocale()}); ?></p>
        </li>




            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
     <?php $__env->endSlot(); ?>



<?php if(session()->has('test')): ?>
<div class="fixed lg:top-5 top-0  lg:left-96 lg:right-96 z-40 bg-yellow-700 p-6 text-center" x-data="{test: true}"  x-init="setTimeout(() => test = false, 10000 )" x-show="test">
    <h1 class="w-full h-full bg-white p-5 capitalize text-xl tracking-widest font-semibold"><?php echo app('translator')->get('lang.ReviewMessage'); ?></h1>
</div>
<?php endif; ?>




<div>

<?php $__currentLoopData = $bgimg; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $bg): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div style="background-image: url(<?php echo e(asset($bg->aboutbg)); ?>);" class="bg-cover bg-center w-full py-60 relative">
        <div class="absolute top-0 left-0 bg-black z-10 w-full h-full opacity-20"> </div>
        <div class="absolute top-0 left-0 h-full w-full flex justify-center items-center z-20">
            <h1 class="text-white text-6xl font-black"><?php echo app('translator')->get('lang.AboutUs'); ?></h1>
        </div>
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>




    <div class="px-4 py-8">

        <?php if(App::getLocale() == 'en'): ?>

        <div class="px-0 lg:px-4 text-3xl font-bold">
            <h1 class="border-b border-black py-4"><?php echo app('translator')->get('lang.LetsKnowEach'); ?> <span class="text-yellow-700"><?php echo app('translator')->get('lang.OtherMore'); ?></span></h1>
        </div>

        <?php else: ?>

        <div class="px-0 lg:px-4 text-3xl font-bold border-b border-black flex justify-end">
            <h1 class=" py-4"><?php echo app('translator')->get('lang.LetsKnowEach'); ?> <span class="text-yellow-700"><?php echo app('translator')->get('lang.OtherMore'); ?></span></h1>
        </div>

        <?php endif; ?>

        <div class="grid grid-cols-1 lg:grid-cols-3 lg:px-32 lg:py-12 pt-4  gap-10 ">

        <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

            <div class="col-span-1 flex flex-col">
                <div style="background-image: url(<?php echo e(asset($info->img)); ?>);" class="bg-cover bg-center w-full lg:h-full h-48" ></div>
            </div>

        <?php if(App::getLocale() == 'en'): ?>

            <div class="flex flex-col gap-4 col-span-2 lg:py-20 py-4">
                <p><?php echo e($info->{'info_'.app()->getLocale()}); ?></p>
            </div>

        <?php else: ?>

            <div class="flex flex-col gap-4 col-span-2 lg:py-20 py-4 text-right">
                <p><?php echo e($info->{'info_'.app()->getLocale()}); ?></p>
            </div>

        <?php endif; ?>


        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
    </div>




    <div style="background-image: url(<?php echo e(asset('imgs/test.jpg')); ?>);" class="w-full py-4 lg:py-16 bg-cover bg-top px-4 lg:px-44 bg-fixed top-0 left-0">
        <div class="lg:h-96 h-fit w-full bg-white py-4 text-center">
            <h1 class="tecking-tighter text-2xl font-black"><?php echo app('translator')->get('lang.WhatOurClients'); ?><span class="text-yellow-700"> <?php echo app('translator')->get('lang.SayAboutUs'); ?></span> </h1>

            <swiper-container class=" mySwiper"  pagination="true" pagination-dynamic-bullets="true"  navigation="true">

                <?php $__currentLoopData = $test; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tst): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                <swiper-slide class="grid grid-cols-1 lg:grid-cols-2 lg:py-16 py-5 px-3 lg:px-10">
                    <div class="flex flex-col justify-between lg:px-12">
                         <p><?php echo e($tst->review); ?></p>
                         <p><?php echo e($tst->job); ?></p>
                     </div>

                     <div class="flex flex-col justify-center items-center mt-5 lg:mt-0">
                        <div style="background-image: url(<?php echo e(asset($tst->image)); ?>);"  class="bg-cover bg-center h-60 w-60 rounded-full"></div>
                    </div>
                </swiper-slide>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



            </swiper-container>

            <div class="py-4">
                <button class="bg-yellow-700 px-4 py-1 text-white font-bold" id="reviewbtn"><?php echo app('translator')->get('lang.AddReview'); ?></button>
            </div>






         <div class="bg-black fixed top-0 left-0 h-full w-full z-30 p-20 opacity-50 hidden transition duration-500" id="reviewlayer"></div>

        <div class="bg-white p-10 overflow-y-scroll z-40 fixed margins flex flex-col gap-6 hidden transition duration-500" id="reviewmodel">
            <div class="flex justify-between">
                <h1 class="text-sm lg:text-xl font-semibold lg:w-full w-1/2"><?php echo app('translator')->get('lang.ReviewTitle'); ?></h1>
                <button class="px-2 text-sm lg:lg lg:px-5 lg:py-1 bg-yellow-700 text-white" id="closebtn"><?php echo app('translator')->get('lang.Close'); ?></button>
            </div>
                <form action="storetest" method="post" enctype="multipart/form-data" class="flex flex-col justify-between h-full lg:h-fit lg:gap-5 py-3">
                    <?php echo csrf_field(); ?>
                    <div class="flex flex-col gap-1 opacity-70 text-left">
                        <span><?php echo app('translator')->get('lang.FullName'); ?></span>
                        <input type="text" name="name" placeholder="eg. Shokrullah Kosha" class="w-full border rounded-lg p-3" required>
                    </div>


                    <div class="flex flex-col gap-1 opacity-70 text-left">
                        <span><?php echo app('translator')->get('lang.Job'); ?></span>
                        <input type="text" name="job" placeholder="eg. Web Developer" class="w-full border rounded-lg p-3" required>
                    </div>



                    <div class="flex flex-col gap-1 opacity-70 text-left">
                        <span><?php echo app('translator')->get('lang.Photo'); ?></span>
                        <input type="file" name="image" class="w-full border rounded-lg p-3" required>
                    </div>



                    <div class="flex flex-col gap-1 opacity-70 text-left">
                        <span><?php echo app('translator')->get('lang.Review'); ?></span>
                        <textarea name="review" id="" cols="4" rows="4"  class="w-full border rounded-lg p-3" placeholder="eg. Shokrullah Kosha is a paragon of freelancers." required></textarea>
                    </div>


                    <button class="bg-yellow-700 px-5 py-1 text-white w-fit mx-auto"><?php echo app('translator')->get('lang.submit'); ?></button>

                </form>

        </div>








        </div>
    </div>






</div>

<script src="https://cdn.jsdelivr.net/npm/swiper@11/swiper-element-bundle.min.js"></script>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\laravel\projects\china\resources\views/frontpages/about.blade.php ENDPATH**/ ?>