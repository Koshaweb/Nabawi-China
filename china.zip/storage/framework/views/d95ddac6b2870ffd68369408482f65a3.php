<?php if (isset($component)) { $__componentOriginal09258b082cb7feea5c3a304d0211a36c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal09258b082cb7feea5c3a304d0211a36c = $attributes; } ?>
<?php $component = App\View\Components\MasterLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('master-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\MasterLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="p-4">
        <!-- /.row -->
        <div class="row wrapper">
          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Orders</h3>


              </div>
              <!-- /.card-header -->
              <div class="card-body table-responsive p-0">
                <table class="table table-hover text-nowrap">
                  <thead>
                    <tr>
                      <th>ID</th>
                      <th>Product Id</th>
                      <th>Product Name</th>
                      <th>Customer Name</th>
                      <th>Customer Number</th>
                      <th>Delivery Type</th>
                      <th>Address</th>
                      <th>Product Details</th>
                      <th>Booked On</th>
                      <th>Button</th>
                    </tr>
                  </thead>
                  <tbody>
                      <?php $__currentLoopData = $booking; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td><?php echo e($book->id); ?></td>
                              <td><?php echo e($book->product_id); ?></td>
                              <td><?php echo e($book->product_name); ?></td>
                              <td><?php echo e($book->name); ?></td>
                              <td><?php echo e($book->number); ?></td>
                              <td><?php echo e($book->delivery); ?></td>
                              <td><?php echo e($book->address); ?></td>
                              <td><?php echo e($book->detail); ?></td>
                              <td><?php echo e($book->created_at); ?></td>

                              <td class="d-flex gap-5">
                                  <a href="allphoto/<?php echo e($book->id); ?>" type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal-danger">Delete</a>
                              </td>
                           </tr>


              
                      <div class="modal fade" id="modal-danger">
                          <div class="modal-dialog">
                            <div class="modal-content bg-danger">
                              <div class="modal-header">
                                <h4 class="modal-title">Are you sure?</h4>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                              </div>
                              <div class="modal-body">
                                <p>If you click 'yes', the information will be deleted permenantly.</p>
                              </div>
                              <div class="modal-footer justify-content-between">
                                <button type="button" class="btn btn-outline-light" data-dismiss="modal">No</button>
                                <a href="allmsgs/<?php echo e($book->id); ?>/delete" type="button" class="btn btn-outline-light">Yes</a>
                              </div>
                            </div>
                            <!-- /.modal-content -->
                          </div>
                          <!-- /.modal-dialog -->
                        </div>
              





                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                  </tbody>
                </table>
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
        </div>
    </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal09258b082cb7feea5c3a304d0211a36c)): ?>
<?php $attributes = $__attributesOriginal09258b082cb7feea5c3a304d0211a36c; ?>
<?php unset($__attributesOriginal09258b082cb7feea5c3a304d0211a36c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal09258b082cb7feea5c3a304d0211a36c)): ?>
<?php $component = $__componentOriginal09258b082cb7feea5c3a304d0211a36c; ?>
<?php unset($__componentOriginal09258b082cb7feea5c3a304d0211a36c); ?>
<?php endif; ?>
<?php /**PATH C:\laravel\projects\china\resources\views/backend/bookings.blade.php ENDPATH**/ ?>