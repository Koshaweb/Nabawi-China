<?php if (isset($component)) { $__componentOriginal09258b082cb7feea5c3a304d0211a36c = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal09258b082cb7feea5c3a304d0211a36c = $attributes; } ?>
<?php $component = App\View\Components\MasterLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('master-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(App\View\Components\MasterLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

    <div class="p-4">

        <!-- general form elements -->
        <div class="card card-primary">
           <div class="card-header">
             <h3 class="card-title">Add Information About the Company</h3>
           </div>
           <!-- /.card-header -->
           <!-- form start -->
           <form action="storecompany" method="POST" enctype="multipart/form-data">
               <?php echo csrf_field(); ?>
             <div class="card-body">


                <div class="form-group">
                    <label >Phone number</label>
                    <input type="number" name="number" class="form-control" placeholder="eg. +923201162723" required">
                    <?php $__errorArgs = ['number'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>



                  <div class="form-group">
                    <label >Email Address</label>
                    <input type="email" name="email" class="form-control" placeholder="eg. sh.kosha2020@gmail.com" required">
                    <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>



                  <div class="form-group">
                    <label >English Address</label>
                    <input type="text" name="address_en" class="form-control" placeholder="eg. Quetta, Pakistan" required">
                    <?php $__errorArgs = ['address_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>





                  <div class="form-group">
                    <label >Persian Address</label>
                    <input type="text" name="address_fa" class="form-control" placeholder="eg. Quetta, Pakistan" required">
                    <?php $__errorArgs = ['address_fa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                          <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>




                  <div class="form-group">
                    <label for="exampleInputFile">An Image of the Map</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" name="map">
                        <label class="custom-file-label">Choose file</label>

                      </div>
                    </div>
                    <?php $__errorArgs = ['map'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>



                  <div class="form-group">
                    <label>English Info</label>
                    <textarea cols="5" rows="5" class="form-control" name="info_en">

                    </textarea>
                    <?php $__errorArgs = ['info_en'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>




                  <div class="form-group">
                    <label>Persian Info</label>
                    <textarea cols="5" rows="5" class="form-control" name="info_fa">

                    </textarea>
                    <?php $__errorArgs = ['info_fa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                         <div class="alert alert-danger"><?php echo e($message); ?></div>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                  </div>




               <div class="form-group">
                   <label for="exampleInputFile">Image of the comapny</label>
                   <div class="input-group">
                     <div class="custom-file">
                       <input type="file" class="custom-file-input" name="img">
                       <label class="custom-file-label">Choose file</label>

                     </div>
                   </div>
                   <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                   <div class="alert alert-danger"><?php echo e($message); ?></div>
                   <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>


             </div>
             <!-- /.card-body -->

             <div class="card-footer">
               <button type="submit" class="btn btn-primary">Submit</button>
             </div>
           </form>
         </div>
         <!-- /.card -->

   </div>






<div class="p-4">
    <!-- /.row -->
    <div class="row wrapper">
      <div class="col-12">
        <div class="card">
          <div class="card-header">
            <h3 class="card-title">All Information</h3>


          </div>
          <!-- /.card-header -->
          <div class="card-body table-responsive p-0">
            <table class="table table-hover">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Number</th>
                  <th>Email</th>
                  <th>Address</th>
                  <th>Image</th>
                  <th>Button</th>
                </tr>
              </thead>
              <tbody>
                  <?php $__currentLoopData = $info; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $infos): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                      <tr>
                          <td><?php echo e($infos->id); ?></td>
                          <td><?php echo e($infos->number); ?></td>
                          <td><?php echo e($infos->email); ?></td>
                          <td><?php echo e($infos->address); ?></td>
                          <td><img src="<?php echo e(asset($infos->img)); ?>" alt="" class="w-25 h-25"></td>

                          <td class="d-flex gap-5">
                              <a href="info/<?php echo e($infos->id); ?>" type="button" class="btn btn-danger" data-toggle="modal" data-target="#modal-danger">Delete</a>
                              <a href="info/<?php echo e($infos->id); ?>/edit"  class="btn btn-info">Edit</a>
                          </td>
                       </tr>


          
                  <div class="modal fade" id="modal-danger">
                      <div class="modal-dialog">
                        <div class="modal-content bg-danger">
                          <div class="modal-header">
                            <h4 class="modal-title">Are you sure?</h4>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>
                          <div class="modal-body">
                            <p>If you click 'yes', the information will be deleted permenantly.</p>
                          </div>
                          <div class="modal-footer justify-content-between">
                            <button type="button" class="btn btn-outline-light" data-dismiss="modal">No</button>
                            <a href="info/<?php echo e($infos->id); ?>/delete" type="button" class="btn btn-outline-light">Yes</a>
                          </div>
                        </div>
                        <!-- /.modal-content -->
                      </div>
                      <!-- /.modal-dialog -->
                    </div>
          





                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

              </tbody>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
      </div>
    </div>
</div>





 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal09258b082cb7feea5c3a304d0211a36c)): ?>
<?php $attributes = $__attributesOriginal09258b082cb7feea5c3a304d0211a36c; ?>
<?php unset($__attributesOriginal09258b082cb7feea5c3a304d0211a36c); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal09258b082cb7feea5c3a304d0211a36c)): ?>
<?php $component = $__componentOriginal09258b082cb7feea5c3a304d0211a36c; ?>
<?php unset($__componentOriginal09258b082cb7feea5c3a304d0211a36c); ?>
<?php endif; ?>
<?php /**PATH C:\laravel\projects\china\resources\views/backend/companyinfo.blade.php ENDPATH**/ ?>