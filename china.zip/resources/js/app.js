import './bootstrap';

import Alpine from 'alpinejs';

window.Alpine = Alpine;

Alpine.start();



const sidebarbtn = document.getElementById('sidebarbtn');
const sidebar = document.getElementById('sidebar');
const closesidebar = document.getElementById('closesidebar');

sidebarbtn.addEventListener('click', function(e){
    e.preventDefault();
    sidebar.style.transform = 'translateX(0px)';
});


closesidebar.addEventListener('click', function(e){
    e.preventDefault();
    sidebar.style.transform = 'translateX(-288px)';
});


const reviewbtn = document.getElementById('reviewbtn');
const reviewlayer = document.getElementById('reviewlayer');
const reviewmodel = document.getElementById('reviewmodel');
const closebtn = document.getElementById('closebtn');

reviewbtn.addEventListener('click', function(e){
    e.preventDefault();
    reviewlayer.style.display= 'block';
    reviewmodel.style.display= 'flex';

});


closebtn.addEventListener('click', function(e){
    e.preventDefault();
    reviewlayer.style.display= 'none';
    reviewmodel.style.display= 'none';

});


reviewlayer.addEventListener('click', function(e){
    e.preventDefault();
    reviewlayer.style.display= 'none';
    reviewmodel.style.display= 'none';

});






